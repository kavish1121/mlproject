import { Component, ElementRef, inject, OnDestroy, OnInit, signal, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from './auth.service';
import { ChatMessage, ChatService } from './chat.service';
import { ReportService } from './report.service';
@Component({ selector: 'app-chat', standalone: true, imports: [CommonModule, FormsModule],
  templateUrl: './chat.component.html', styleUrl: './chat.component.css' })
export class ChatComponent implements OnInit, OnDestroy {
  readonly auth = inject(AuthService);
  private readonly chat = inject(ChatService);
  private readonly reports = inject(ReportService);
  @ViewChild('conversation') conversation?: ElementRef<HTMLElement>;
  readonly messages = signal<ChatMessage[]>([]);
  readonly ready = signal(false);
  readonly thinking = signal(false);
  readonly reportBusy = signal(false);
  readonly reportStatus = signal('');
  readonly error = signal('');
  text = '';
  private reportTimer?: ReturnType<typeof setTimeout>;
  private destroyed = false;
  async ngOnInit() {
    try {
      await this.auth.initialize();
      this.chat.connect();
      this.messages.set(await this.chat.history());
      this.ready.set(true); this.scrollToBottom();
      const job = sessionStorage.getItem('report-job');
      if (job) { this.reportBusy.set(true); await this.checkReport(job); }
    } catch (error) { this.error.set(this.errorText(error)); }
  }
  async send() {
    const text = this.text.trim();
    if (!text || this.thinking() || !this.ready()) return;
    const requestId = crypto.randomUUID();
    this.text = ''; this.error.set(''); this.thinking.set(true);
    const userMessage: ChatMessage = { id: requestId, request_id: requestId, role: 'user', content: text, status: 'pending', created_at: new Date().toISOString() };
    this.messages.update(messages => [...messages, userMessage]); this.scrollToBottom();
    try {
      const reply = await this.chat.send(text, requestId);
      this.messages.update(messages => [...messages.map(m => m.id === requestId ? { ...m, status: 'complete' as const } : m), reply]);
    } catch (error) {
      this.error.set(this.errorText(error));
      // Reload persisted state after an uncertain socket result; never silently resend a message.
      try { this.messages.set(await this.chat.history()); } catch { /* Keep visible messages if offline. */ }
      this.text = text;
    } finally { this.thinking.set(false); this.scrollToBottom(); }
  }
  async generateReport() {
    if (this.reportBusy()) return;
    this.reportBusy.set(true); this.reportStatus.set('Submitting report…');
    // Keep the ID after a network failure, so retrying submission reuses the same queue job.
    const requestId = sessionStorage.getItem('report-request') || crypto.randomUUID();
    sessionStorage.setItem('report-request', requestId);
    try {
      const { jobId } = await this.reports.generate(requestId);
      sessionStorage.setItem('report-job', jobId);
      await this.checkReport(jobId);
    } catch (error) { this.reportStatus.set(this.errorText(error)); this.reportBusy.set(false); }
  }
  private async checkReport(jobId: string) {
    if (this.destroyed) return;
    try {
      const result = await this.reports.status(jobId);
      if (result.state === 'completed' || result.state === 'failed') {
        this.reportStatus.set(result.state === 'completed' ? 'Report sent to your email server.' : result.error || 'Report failed.');
        this.reportBusy.set(false); sessionStorage.removeItem('report-job'); sessionStorage.removeItem('report-request'); return;
      }
      this.reportStatus.set(result.progress?.stage || 'Report queued…');
      this.reportTimer = setTimeout(() => { void this.checkReport(jobId); }, 2000);
    } catch (error) { this.reportStatus.set(`${this.errorText(error)} Refresh to check report status.`); this.reportBusy.set(false); }
  }
  private scrollToBottom() { setTimeout(() => { const area = this.conversation?.nativeElement; if (area) area.scrollTop = area.scrollHeight; }); }
  private errorText(error: unknown) { return error instanceof Error ? error.message : 'Something went wrong. Please try again.'; }
  ngOnDestroy() { this.destroyed = true; clearTimeout(this.reportTimer); this.chat.disconnect(); }
}
