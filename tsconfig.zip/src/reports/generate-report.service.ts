import { Inject, Injectable } from '@nestjs/common';
import { BatchApiService } from './batch-api.service';
import { ExcelService } from './excel.service';
import { SendNotificationsService } from './send-notifications.service';
export interface ReportRequest { userId: string; email: string }
@Injectable()
export class GenerateReportService {
  constructor(@Inject(BatchApiService) private readonly batchApi: BatchApiService,
    @Inject(ExcelService) private readonly excel: ExcelService,
    @Inject(SendNotificationsService) private readonly notifications: SendNotificationsService) {}
  async generate(request: ReportRequest, jobId: string, progress: (stage: string) => Promise<void>) {
    await progress('Fetching report data');
    const data = await this.batchApi.getData(request.userId);
    await progress('Generating Excel');
    const attachment = await this.excel.create(data);
    await progress('Sending email');
    await this.notifications.sendReport(request.email, attachment, jobId);
    return { message: 'Report accepted by the mail server.' };
  }
}
