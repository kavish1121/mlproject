import { Injectable } from '@nestjs/common';
import nodemailer from 'nodemailer';
import { config } from '../config';
@Injectable()
export class SendNotificationsService {
  private readonly transport = nodemailer.createTransport({ host: config.SMTP_HOST, port: config.SMTP_PORT,
    secure: config.SMTP_SECURE === 'true', connectionTimeout: 15000, socketTimeout: 30000,
    auth: config.SMTP_USER ? { user: config.SMTP_USER, pass: config.SMTP_PASSWORD } : undefined });
  async sendReport(email: string, attachment: Buffer, jobId: string) {
    const result = await this.transport.sendMail({ from: config.MAIL_FROM, to: email,
      subject: 'Your requested report', text: 'Your requested Excel report is attached.',
      messageId: `<report-${jobId}@${config.MAIL_FROM.split('@')[1]}>`,
      attachments: [{ filename: 'report.xlsx', content: attachment,
        contentType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }] });
    if (!result.accepted.length) throw new Error('Mail server did not accept the report');
  }
}
