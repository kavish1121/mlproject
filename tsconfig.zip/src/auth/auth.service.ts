import { Injectable, UnauthorizedException } from '@nestjs/common';
import { createRemoteJWKSet, jwtVerify } from 'jose';
import { config } from '../config';
export interface ChatUser { id: string; email?: string; name: string }
@Injectable()
export class AuthService {
  private readonly issuer = `${config.KEYCLOAK_URL.replace(/\/$/, '')}/realms/${config.KEYCLOAK_REALM}`;
  private readonly jwks = config.AUTH_MODE === 'keycloak'
    ? createRemoteJWKSet(new URL(`${this.issuer}/protocol/openid-connect/certs`)) : undefined;
  async authenticate(token: unknown): Promise<ChatUser> {
    if (typeof token !== 'string') throw new UnauthorizedException();
    if (config.AUTH_MODE === 'demo') {
      if (token !== 'local-demo') throw new UnauthorizedException();
      return { id: 'local-demo', email: 'demo@local.test', name: 'Demo user' };
    }
    try {
      const { payload } = await jwtVerify(token, this.jwks!, { issuer: this.issuer, audience: config.KEYCLOAK_AUDIENCE, algorithms: ['RS256'] });
      if (!payload.sub) throw new Error('Missing subject');
      return { id: payload.sub, name: String(payload.preferred_username || payload.sub),
        email: payload.email_verified === true && typeof payload.email === 'string' ? payload.email : undefined };
    } catch { throw new UnauthorizedException('Please sign in again.'); }
  }
}
