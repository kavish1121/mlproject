import 'dotenv/config';
import { z } from 'zod';
const schema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  HOST: z.string().default('127.0.0.1'), PORT: z.coerce.number().int().positive().default(3000),
  FRONTEND_ORIGIN: z.url().default('http://localhost:4200'),
  AUTH_MODE: z.enum(['demo', 'keycloak']).default('keycloak'),
  DATABASE_URL: z.string().min(1), REDIS_HOST: z.string().default('localhost'),
  REDIS_PORT: z.coerce.number().default(6379), REDIS_PASSWORD: z.string().default(''),
  API_MODE: z.enum(['mock', 'http']).default('http'),
  CHAT_API_URL: z.string().default(''), BATCH_API_URL: z.string().default(''),
  UPSTREAM_API_TOKEN: z.string().default(''), API_TIMEOUT_MS: z.coerce.number().positive().default(30000),
  KEYCLOAK_URL: z.string().default(''), KEYCLOAK_REALM: z.string().default(''),
  KEYCLOAK_CLIENT_ID: z.string().default(''), KEYCLOAK_AUDIENCE: z.string().default(''),
  SMTP_HOST: z.string().default('localhost'), SMTP_PORT: z.coerce.number().default(1025),
  SMTP_SECURE: z.enum(['true','false']).default('false'), SMTP_USER: z.string().default(''),
  SMTP_PASSWORD: z.string().default(''), MAIL_FROM: z.email().default('chat@local.test'),
});
export const config = schema.parse(process.env);
if (config.AUTH_MODE === 'demo' && (config.NODE_ENV === 'production' || !['127.0.0.1','localhost','::1'].includes(config.HOST))) {
  throw new Error('Demo authentication is only allowed on a local development interface.');
}
if (config.NODE_ENV === 'production' && config.API_MODE === 'mock') throw new Error('Mock APIs are disabled in production.');
if (config.AUTH_MODE === 'keycloak') {
  for (const key of ['KEYCLOAK_URL','KEYCLOAK_REALM','KEYCLOAK_CLIENT_ID','KEYCLOAK_AUDIENCE'] as const) {
    if (!config[key]) throw new Error(`${key} is required`);
  }
}
if (config.API_MODE === 'http' && (!config.CHAT_API_URL || !config.BATCH_API_URL)) throw new Error('Both upstream API URLs are required.');
export const redisConnection = { host: config.REDIS_HOST, port: config.REDIS_PORT, password: config.REDIS_PASSWORD || undefined };
