import { Injectable } from '@nestjs/common';
import ExcelJS from 'exceljs';
import { ReportData } from './batch-api.service';
@Injectable()
export class ExcelService {
  async create(data: ReportData): Promise<Buffer> {
    const book = new ExcelJS.Workbook();
    const sheet = book.addWorksheet('Report');
    sheet.addRow(data.columns.map(c => c.label));
    for (const row of data.rows) {
      // Only primitive cell values are accepted. Strings beginning '=' remain text, never formulas.
      sheet.addRow(data.columns.map(c => row[c.key] ?? null));
    }
    sheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
    sheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF153654' } };
    sheet.columns.forEach(column => { column.width = 24; });
    sheet.views = [{ state: 'frozen', ySplit: 1 }];
    const buffer = Buffer.from(await book.xlsx.writeBuffer());
    if (buffer.length > 5 * 1024 * 1024) throw new Error('Report exceeds 5 MB attachment limit');
    return buffer;
  }
}
