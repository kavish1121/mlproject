import { Injectable } from '@nestjs/common';
import { z } from 'zod';
import { config } from '../config';
import { callApi } from '../chat/chat-api.service';
export const reportDataSchema = z.object({
  columns: z.array(z.object({ key: z.string().min(1).max(100), label: z.string().min(1).max(100) })).min(1).max(50),
  rows: z.array(z.record(z.string(), z.union([z.string().max(32000), z.number().finite(), z.boolean(), z.null()]))).max(10000),
}).refine(data => new Set(data.columns.map(c => c.key)).size === data.columns.length, 'Column keys must be unique');
export type ReportData = z.infer<typeof reportDataSchema>;
@Injectable()
export class BatchApiService {
  async getData(userId: string): Promise<ReportData> {
    if (config.API_MODE === 'mock') return {
      columns: [{ key: 'asset', label: 'Asset' }, { key: 'reading', label: 'Reading' }, { key: 'status', label: 'Status' }],
      rows: [{ asset: 'Machine 001', reading: 42, status: 'Normal' }, { asset: 'Machine 002', reading: 76, status: 'Review' }],
    };
    return reportDataSchema.parse(await callApi(config.BATCH_API_URL, { userId, reportType: 'standard' }));
  }
}
