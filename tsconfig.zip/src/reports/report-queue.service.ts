import { Inject, Injectable, Logger, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { Queue, Worker } from 'bullmq';
import { redisConnection } from '../config';
import { GenerateReportService, ReportRequest } from './generate-report.service';
@Injectable()
export class ReportQueueService implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(ReportQueueService.name);
  private readonly queue = new Queue<ReportRequest>('reports', { connection: redisConnection });
  private worker?: Worker;
  constructor(@Inject(GenerateReportService) private readonly generateReport: GenerateReportService) {}
  onModuleInit() {
    this.queue.on('error', () => this.logger.error('Report queue unavailable; check Redis.'));
    this.worker = new Worker<ReportRequest>('reports', async job => {
      try { return await this.generateReport.generate(job.data, job.id!, stage => job.updateProgress({ stage })); }
      catch { throw new Error('Report failed. Check the API and mail service. Email delivery may be uncertain.'); }
    }, { connection: redisConnection, concurrency: 1, maxStalledCount: 0 });
    this.worker.on('error', () => this.logger.error('Report worker unavailable; check Redis.'));
    this.worker.on('failed', job => this.logger.warn(`Report job ${job?.id} failed; inspect status before resubmitting.`));
  }
  async enqueue(request: ReportRequest, jobId: string) {
    // Same job ID prevents a network retry from creating a second email job while retained.
    const job = await this.queue.add('generate-and-email', request, { jobId, attempts: 1,
      removeOnComplete: { age: 86400, count: 1000 }, removeOnFail: { age: 604800, count: 1000 } });
    return job.id!;
  }
  async status(id: string, userId: string) {
    const job = await this.queue.getJob(id);
    if (!job || job.data.userId !== userId) return null;
    return { jobId: job.id, state: await job.getState(), progress: job.progress,
      message: job.returnvalue?.message, error: job.failedReason || undefined };
  }
  async onModuleDestroy() { await this.worker?.close(); await this.queue.close(); }
}
