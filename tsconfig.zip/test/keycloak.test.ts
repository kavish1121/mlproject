import 'reflect-metadata';
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { generateKeyPair, exportJWK, SignJWT } from 'jose';

test('Keycloak JWT validation checks signature, issuer, audience, expiry and email verification', async () => {
  const { privateKey, publicKey } = await generateKeyPair('RS256');
  const jwk = { ...await exportJWK(publicKey), kid:'test-key', alg:'RS256', use:'sig' };
  const server = createServer((_req,res) => { res.setHeader('Content-Type','application/json'); res.end(JSON.stringify({keys:[jwk]})); });
  await new Promise<void>(resolve => server.listen(0,'127.0.0.1',resolve));
  const address = server.address() as {port:number}; const base = `http://127.0.0.1:${address.port}`;
  process.env.NODE_ENV='test'; process.env.AUTH_MODE='keycloak'; process.env.API_MODE='mock';
  process.env.DATABASE_URL='postgresql://unused'; process.env.KEYCLOAK_URL=base;
  process.env.KEYCLOAK_REALM='test'; process.env.KEYCLOAK_CLIENT_ID='chat-ui'; process.env.KEYCLOAK_AUDIENCE='chat-api';
  const {AuthService} = await import('../src/auth/auth.service'); const auth = new AuthService();
  const token = (aud='chat-api', issuer=`${base}/realms/test`, exp='1h', verified=true) =>
    new SignJWT({email:'alice@example.test',email_verified:verified,preferred_username:'alice'})
      .setProtectedHeader({alg:'RS256',kid:'test-key'}).setSubject('alice').setIssuer(issuer).setAudience(aud)
      .setIssuedAt().setExpirationTime(exp).sign(privateKey);
  try {
    assert.equal((await auth.authenticate(await token())).id,'alice');
    assert.equal((await auth.authenticate(await token('chat-api',`${base}/realms/test`,'1h',false))).email,undefined);
    await assert.rejects(() => auth.authenticate('local-demo'));
    await assert.rejects(async () => auth.authenticate(await token('wrong-audience')));
    await assert.rejects(async () => auth.authenticate(await token('chat-api','wrong-issuer')));
    await assert.rejects(async () => auth.authenticate(await token('chat-api',`${base}/realms/test`,'-1h')));
    const other = await generateKeyPair('RS256');
    const fake = await new SignJWT({}).setProtectedHeader({alg:'RS256',kid:'test-key'}).setSubject('alice')
      .setIssuer(`${base}/realms/test`).setAudience('chat-api').setExpirationTime('1h').sign(other.privateKey);
    await assert.rejects(() => auth.authenticate(fake));
  } finally { server.closeAllConnections(); await new Promise<void>(resolve => server.close(() => resolve())); }
});
