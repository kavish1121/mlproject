import 'reflect-metadata';
import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';
import { randomUUID } from 'node:crypto';
import { newDb } from 'pg-mem';
import ExcelJS from 'exceljs';
// Configure before importing application modules. No real credentials or services needed.
process.env.AUTH_MODE = 'demo'; process.env.NODE_ENV = 'test'; process.env.API_MODE = 'mock';
process.env.DATABASE_URL = 'postgresql://unused';

test('chat persists both messages and isolates history by user', async () => {
  const { ChatHistoryService } = await import('../src/chat/chat-history.service');
  const { ChatService } = await import('../src/chat/chat.service');
  const { ChatApiService } = await import('../src/chat/chat-api.service');
  const memory = newDb(); memory.public.none(readFileSync('src/database/schema.sql','utf8'));
  const { Pool } = memory.adapters.createPg(); const pool = new Pool();
  const history = new ChatHistoryService({ pool } as any);
  const chat = new ChatService(history, new ChatApiService()); const request = randomUUID();
  await chat.send('alice', request, 'Hello');
  const saved = await history.list('alice');
  assert.equal(saved.length, 2); assert.ok(saved.every(m => m.status === 'complete'));
  assert.equal((await history.list('bob')).length, 0);
  await assert.rejects(() => chat.send('alice', request, 'Hello'));
  assert.equal((await history.list('alice')).length, 2);
  await pool.end();
});

test('API failure marks the user message failed without inventing an assistant reply', async () => {
  const { ChatHistoryService } = await import('../src/chat/chat-history.service');
  const { ChatService } = await import('../src/chat/chat.service');
  const memory = newDb(); memory.public.none(readFileSync('src/database/schema.sql','utf8'));
  const { Pool } = memory.adapters.createPg(); const pool = new Pool();
  const history = new ChatHistoryService({ pool } as any);
  const chat = new ChatService(history, { reply: async () => { throw new Error('Unavailable'); } } as any);
  await assert.rejects(() => chat.send('alice', randomUUID(), 'Hello'));
  const saved = await history.list('alice'); assert.equal(saved.length,1); assert.equal(saved[0].status,'failed');
  await pool.end();
});

test('Excel contains API column order, numeric values and safe text cells', async () => {
  const { ExcelService } = await import('../src/reports/excel.service');
  const buffer = await new ExcelService().create({ columns: [{key:'name',label:'Asset'},{key:'reading',label:'Reading'}],
    rows:[{name:'=HYPERLINK("bad")',reading:42}] });
  const book = new ExcelJS.Workbook(); await book.xlsx.load(buffer as any);
  const sheet = book.getWorksheet('Report')!;
  assert.equal(sheet.getCell('A1').value,'Asset'); assert.equal(sheet.getCell('B2').value,42);
  assert.equal(sheet.getCell('A2').type,ExcelJS.ValueType.String);
});

test('report pipeline calls batch API, creates Excel and sends one attachment', async () => {
  const { GenerateReportService } = await import('../src/reports/generate-report.service');
  const { BatchApiService } = await import('../src/reports/batch-api.service');
  const { ExcelService } = await import('../src/reports/excel.service');
  const stages: string[] = []; let emails = 0;
  const service = new GenerateReportService(new BatchApiService(), new ExcelService(), {
    sendReport: async (email:string, attachment:Buffer) => { assert.equal(email,'alice@example.test'); assert.ok(attachment.length > 100); emails++; }
  } as any);
  await service.generate({userId:'alice',email:'alice@example.test'},'job',async stage => {stages.push(stage);});
  assert.equal(emails,1); assert.deepEqual(stages,['Fetching report data','Generating Excel','Sending email']);
});

test('report rejects malformed API data and duplicate column keys', async () => {
  const { reportDataSchema } = await import('../src/reports/batch-api.service');
  assert.equal(reportDataSchema.safeParse({columns:[],rows:[]}).success,false);
  assert.equal(reportDataSchema.safeParse({columns:[{key:'a',label:'A'},{key:'a',label:'B'}],rows:[]}).success,false);
  assert.equal(reportDataSchema.safeParse({columns:[{key:'a',label:'A'}],rows:[{a:{formula:'1+1'}}]}).success,false);
});

test('authentication rejects missing or arbitrary demo tokens', async () => {
  const { AuthService } = await import('../src/auth/auth.service');
  const auth = new AuthService();
  await assert.rejects(() => auth.authenticate(undefined));
  await assert.rejects(() => auth.authenticate('bad-token'));
  assert.equal((await auth.authenticate('local-demo')).id,'local-demo');
});

test('report controller uses authenticated identity and verified email, never request recipient', async () => {
  const { ReportController } = await import('../src/reports/report.controller');
  const requests:any[] = [];
  const controller = new ReportController({enqueue:async (body:any,id:string) => {requests.push(body); return id;}, status:async()=>null} as any);
  const user = {id:'alice',email:'alice@example.test',name:'Alice'};
  await controller.generate({user} as any,{requestId:randomUUID()});
  assert.deepEqual(requests[0],{userId:'alice',email:'alice@example.test'});
  await assert.rejects(() => controller.generate({user} as any,{requestId:randomUUID(),email:'other@example.test'}));
  await assert.rejects(() => controller.generate({user:{id:'alice'}} as any,{requestId:randomUUID()}));
  await assert.rejects(() => controller.status({user} as any,'invalid'));
});
