import { inject, Injectable } from '@angular/core';
import { AuthService } from './auth.service';
export interface ReportStatus { jobId: string; state: string; progress?: { stage?: string }; message?: string; error?: string }
@Injectable({ providedIn: 'root' })
export class ReportService {
  private readonly auth = inject(AuthService);
  generate(requestId: string) { return this.auth.request<{ jobId: string }>('/api/reports', { method: 'POST', body: JSON.stringify({ requestId }) }); }
  status(jobId: string) { return this.auth.request<ReportStatus>(`/api/reports/${encodeURIComponent(jobId)}`); }
}
