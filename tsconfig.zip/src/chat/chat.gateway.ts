import { Inject } from '@nestjs/common';
import { ConnectedSocket, MessageBody, OnGatewayInit, SubscribeMessage, WebSocketGateway } from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { z } from 'zod';
import { AuthService } from '../auth/auth.service';
import { ChatService } from './chat.service';
import { config } from '../config';
const messageSchema = z.object({ requestId: z.uuid(), text: z.string().trim().min(1).max(4000), token: z.string().min(1) }).strict();
@WebSocketGateway({ cors: { origin: config.FRONTEND_ORIGIN }, maxHttpBufferSize: 20000 })
export class ChatGateway implements OnGatewayInit {
  constructor(@Inject(AuthService) private readonly auth: AuthService, @Inject(ChatService) private readonly chat: ChatService) {}
  afterInit(server: Server) {
    server.use(async (socket, next) => {
      try { socket.data.user = await this.auth.authenticate(socket.handshake.auth.token); next(); }
      catch { next(new Error('Authentication required')); }
    });
  }
  @SubscribeMessage('chat:send')
  async send(@ConnectedSocket() socket: Socket, @MessageBody() body: unknown) {
    const parsed = messageSchema.safeParse(body);
    if (!parsed.success) return { ok: false, error: 'Enter a message of 1–4000 characters.' };
    try {
      // Validate again on every message: a connected socket must not outlive its token.
      const user = await this.auth.authenticate(parsed.data.token);
      if (user.id !== socket.data.user.id) throw new Error('Identity changed');
      const message = await this.chat.send(user.id, parsed.data.requestId, parsed.data.text);
      return { ok: true, message };
    } catch { return { ok: false, error: 'Unable to get a reply. Check your connection or sign in again.' }; }
  }
}
