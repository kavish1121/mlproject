import { Inject, Injectable } from '@nestjs/common';
import { randomUUID } from 'node:crypto';
import { DatabaseService } from '../database/database.service';
export interface ChatMessage { id: string; request_id: string; role: 'user'|'assistant'; content: string; status: 'pending'|'complete'|'failed'; created_at: string }
@Injectable()
export class ChatHistoryService {
  constructor(@Inject(DatabaseService) private readonly db: DatabaseService) {}
  async list(userId: string): Promise<ChatMessage[]> {
    const result = await this.db.pool.query(`SELECT id, request_id, role, content, status, created_at FROM
      (SELECT * FROM chat_messages WHERE user_id=$1 ORDER BY sequence DESC LIMIT 100) recent
      ORDER BY sequence`, [userId]);
    return result.rows;
  }
  async begin(userId: string, requestId: string, content: string) {
    const result = await this.db.pool.query(`INSERT INTO chat_messages(id,user_id,request_id,role,content,status)
      VALUES($1,$2,$3,'user',$4,'pending') ON CONFLICT(user_id,request_id,role) DO NOTHING RETURNING id`,
      [randomUUID(),userId,requestId,content]);
    return result.rowCount === 1;
  }
  async complete(userId: string, requestId: string, content: string): Promise<ChatMessage> {
    const client = await this.db.pool.connect();
    try {
      await client.query('BEGIN');
      const result = await client.query(`INSERT INTO chat_messages(id,user_id,request_id,role,content,status)
        VALUES($1,$2,$3,'assistant',$4,'complete') RETURNING id,request_id,role,content,status,created_at`, [randomUUID(),userId,requestId,content]);
      await client.query(`UPDATE chat_messages SET status='complete' WHERE user_id=$1 AND request_id=$2 AND role='user'`,[userId,requestId]);
      await client.query('COMMIT'); return result.rows[0];
    } catch (error) { await client.query('ROLLBACK'); throw error; }
    finally { client.release(); }
  }
  async fail(userId: string, requestId: string) {
    await this.db.pool.query(`UPDATE chat_messages SET status='failed' WHERE user_id=$1 AND request_id=$2 AND role='user'`,[userId,requestId]);
  }
}
