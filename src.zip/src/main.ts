import { bootstrapApplication } from '@angular/platform-browser';
import { ChatComponent } from './app/chat.component';
bootstrapApplication(ChatComponent).catch(() => {
  document.body.textContent = 'The application could not start. Please refresh the page.';
});
