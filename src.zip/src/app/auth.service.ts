import { Injectable } from '@angular/core';
import Keycloak from 'keycloak-js';
export interface AppConfig { authMode: 'demo'|'keycloak'; apiMode: 'mock'|'http'; keycloak: { url: string; realm: string; clientId: string } }
@Injectable({ providedIn: 'root' })
export class AuthService {
  config?: AppConfig;
  private keycloak?: Keycloak;
  async initialize() {
    const response = await fetch('/api/config');
    if (!response.ok) throw new Error('Backend is unavailable.');
    this.config = await response.json();
    if (this.config!.authMode === 'keycloak') {
      this.keycloak = new Keycloak(this.config!.keycloak);
      await this.keycloak.init({ onLoad: 'login-required', pkceMethod: 'S256', checkLoginIframe: false });
    }
  }
  async token(): Promise<string> {
    if (!this.config) throw new Error('Authentication is not initialized.');
    if (this.config.authMode === 'demo') return 'local-demo';
    try { await this.keycloak!.updateToken(60); }
    catch { await this.keycloak!.login(); throw new Error('Please sign in again.'); }
    if (!this.keycloak!.token) throw new Error('Please sign in again.');
    return this.keycloak!.token;
  }
  logout() { return this.keycloak?.logout({ redirectUri: window.location.origin }); }
  async request<T>(url: string, options: RequestInit = {}): Promise<T> {
    const response = await fetch(url, { ...options, headers: { 'Content-Type': 'application/json',
      Authorization: `Bearer ${await this.token()}` }, signal: AbortSignal.timeout(15000) });
    if (!response.ok) {
      if (response.status === 401) throw new Error('Session expired. Please sign in again.');
      const error = await response.json().catch(() => ({}));
      throw new Error(typeof error.message === 'string' ? error.message : 'Request failed. Please try again.');
    }
    return response.json();
  }
}
