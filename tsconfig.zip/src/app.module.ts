import { Controller, Get, Module } from '@nestjs/common';
import { config } from './config';
import { AuthService } from './auth/auth.service';
import { AuthGuard } from './auth/auth.guard';
import { DatabaseService } from './database/database.service';
import { ChatHistoryService } from './chat/chat-history.service';
import { ChatApiService } from './chat/chat-api.service';
import { ChatService } from './chat/chat.service';
import { ChatGateway } from './chat/chat.gateway';
import { ChatController } from './chat/chat.controller';
import { BatchApiService } from './reports/batch-api.service';
import { ExcelService } from './reports/excel.service';
import { SendNotificationsService } from './reports/send-notifications.service';
import { GenerateReportService } from './reports/generate-report.service';
import { ReportQueueService } from './reports/report-queue.service';
import { ReportController } from './reports/report.controller';
@Controller()
class AppController {
  @Get('health') health() { return { status: 'ok' }; }
  @Get('config') publicConfig() { return { authMode: config.AUTH_MODE, apiMode: config.API_MODE,
    keycloak: { url: config.KEYCLOAK_URL, realm: config.KEYCLOAK_REALM, clientId: config.KEYCLOAK_CLIENT_ID } }; }
}
@Module({ controllers: [AppController, ChatController, ReportController], providers: [AuthService, AuthGuard,
  DatabaseService, ChatHistoryService, ChatApiService, ChatService, ChatGateway, BatchApiService,
  ExcelService, SendNotificationsService, GenerateReportService, ReportQueueService] })
export class AppModule {}
