import { Injectable } from '@nestjs/common';
import { z } from 'zod';
import { config } from '../config';
export const chatResponseSchema = z.object({ reply: z.string().min(1).max(50000) });
export async function callApi(url: string, body: unknown) {
  const response = await fetch(url, { method: 'POST', signal: AbortSignal.timeout(config.API_TIMEOUT_MS),
    headers: { 'Content-Type': 'application/json', ...(config.UPSTREAM_API_TOKEN ? { Authorization: `Bearer ${config.UPSTREAM_API_TOKEN}` } : {}) },
    body: JSON.stringify(body) });
  if (!response.ok) throw new Error(`Upstream HTTP ${response.status}`);
  // Bound the response before JSON parsing; do not trust Content-Length alone.
  const reader = response.body?.getReader(); if (!reader) throw new Error('Empty response');
  const chunks: Uint8Array[] = []; let size = 0;
  try {
    while (true) { const part = await reader.read(); if (part.done) break;
      size += part.value.length; if (size > 5 * 1024 * 1024) throw new Error('API response exceeds 5 MB'); chunks.push(part.value); }
  } finally { await reader.cancel(); }
  return JSON.parse(Buffer.concat(chunks).toString('utf8'));
}
@Injectable()
export class ChatApiService {
  async reply(userId: string, message: string, history: { role: string; content: string }[]) {
    if (config.API_MODE === 'mock') return `Demo response: You asked “${message}”. The chat connection is working. The real API team will provide the answer here.`;
    return chatResponseSchema.parse(await callApi(config.CHAT_API_URL, { userId, message, history })).reply;
  }
}
