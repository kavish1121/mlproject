import { Inject, Injectable } from '@nestjs/common';
import { ChatHistoryService } from './chat-history.service';
import { ChatApiService } from './chat-api.service';
@Injectable()
export class ChatService {
  private readonly activeUsers = new Set<string>();
  constructor(@Inject(ChatHistoryService) private readonly history: ChatHistoryService,
    @Inject(ChatApiService) private readonly api: ChatApiService) {}
  async send(userId: string, requestId: string, text: string) {
    if (this.activeUsers.has(userId)) throw new Error('A reply is already being generated.');
    this.activeUsers.add(userId);
    let started = false;
    try {
      const previous = await this.history.list(userId);
      started = await this.history.begin(userId, requestId, text);
      if (!started) throw new Error('Request already submitted. Refresh history to check it.');
      const context = previous.filter(m => m.status === 'complete').slice(-20).map(({role, content}) => ({role,content}));
      const reply = await this.api.reply(userId, text, context);
      return await this.history.complete(userId, requestId, reply);
    } catch (error) { if (started) await this.history.fail(userId, requestId); throw error; }
    finally { this.activeUsers.delete(userId); }
  }
}
