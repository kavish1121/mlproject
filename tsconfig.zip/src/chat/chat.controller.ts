import { Controller, Get, Inject, Req, UseGuards } from '@nestjs/common';
import { AuthGuard, AuthenticatedRequest } from '../auth/auth.guard';
import { ChatHistoryService } from './chat-history.service';
@Controller('chat')
@UseGuards(AuthGuard)
export class ChatController {
  constructor(@Inject(ChatHistoryService) private readonly history: ChatHistoryService) {}
  @Get('history') historyForUser(@Req() request: AuthenticatedRequest) { return this.history.list(request.user.id); }
}
