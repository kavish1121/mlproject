import 'reflect-metadata';
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { randomUUID } from 'node:crypto';
import { Module } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { newDb } from 'pg-mem';
import { io } from 'socket.io-client';
process.env.AUTH_MODE='demo'; process.env.NODE_ENV='test'; process.env.API_MODE='mock'; process.env.DATABASE_URL='postgresql://unused';

test('HTTP history requires authentication; Socket.IO sends and restores persisted chat', async () => {
  const { AuthService } = await import('../src/auth/auth.service');
  const { AuthGuard } = await import('../src/auth/auth.guard');
  const { DatabaseService } = await import('../src/database/database.service');
  const { ChatHistoryService } = await import('../src/chat/chat-history.service');
  const { ChatApiService } = await import('../src/chat/chat-api.service');
  const { ChatService } = await import('../src/chat/chat.service');
  const { ChatController } = await import('../src/chat/chat.controller');
  const { ChatGateway } = await import('../src/chat/chat.gateway');
  const memory=newDb(); memory.public.none(readFileSync('src/database/schema.sql','utf8'));
  const {Pool}=memory.adapters.createPg(); const pool=new Pool();
  @Module({controllers:[ChatController],providers:[AuthService,AuthGuard,ChatHistoryService,ChatApiService,ChatService,ChatGateway,
    {provide:DatabaseService,useValue:{pool}}]}) class TestModule {}
  const app = await NestFactory.create(TestModule,{logger:false}); app.setGlobalPrefix('api'); await app.listen(0,'127.0.0.1');
  const url=await app.getUrl(); const socket=io(url,{autoConnect:false,auth:{token:'local-demo'}});
  const denied=io(url,{autoConnect:false,reconnection:false,auth:{token:'wrong'}});
  try {
    assert.equal((await fetch(`${url}/api/chat/history`)).status,401);
    const deniedResult=new Promise<string>(resolve=>denied.once('connect_error',error=>resolve(error.message))); denied.connect();
    assert.equal(await deniedResult,'Authentication required');
    const connected=new Promise<void>(resolve=>socket.once('connect',()=>resolve())); socket.connect(); await connected;
    const reply=await socket.timeout(5000).emitWithAck('chat:send',{requestId:randomUUID(),text:'Hello socket',token:'local-demo'});
    assert.equal(reply.ok,true);
    const headers={Authorization:'Bearer local-demo'};
    const saved=await (await fetch(`${url}/api/chat/history`,{headers})).json() as any[];
    assert.equal(saved.length,2); assert.equal(saved[0].content,'Hello socket');
    const invalid=await socket.timeout(5000).emitWithAck('chat:send',{requestId:randomUUID(),text:'hello',token:'expired'});
    assert.equal(invalid.ok,false);
  } finally {socket.disconnect();denied.disconnect();await app.close();await pool.end();}
});
