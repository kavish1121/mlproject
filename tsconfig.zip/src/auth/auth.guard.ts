import { CanActivate, ExecutionContext, Inject, Injectable } from '@nestjs/common';
import { AuthService, ChatUser } from './auth.service';
import { Request } from 'express';
export type AuthenticatedRequest = Request & { user: ChatUser };
@Injectable()
export class AuthGuard implements CanActivate {
  constructor(@Inject(AuthService) private readonly auth: AuthService) {}
  async canActivate(context: ExecutionContext) {
    const request = context.switchToHttp().getRequest<AuthenticatedRequest>();
    request.user = await this.auth.authenticate(request.headers.authorization?.replace(/^Bearer /, ''));
    return true;
  }
}
