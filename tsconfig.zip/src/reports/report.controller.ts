import { BadRequestException, Body, Controller, Get, HttpCode, Inject, NotFoundException, Param, Post, Req, UseGuards } from '@nestjs/common';
import { createHash } from 'node:crypto';
import { z } from 'zod';
import { AuthGuard, AuthenticatedRequest } from '../auth/auth.guard';
import { ReportQueueService } from './report-queue.service';
@Controller('reports')
@UseGuards(AuthGuard)
export class ReportController {
  constructor(@Inject(ReportQueueService) private readonly queue: ReportQueueService) {}
  @Post() @HttpCode(202)
  async generate(@Req() request: AuthenticatedRequest, @Body() body: unknown) {
    const input = z.object({ requestId: z.uuid() }).strict().safeParse(body);
    if (!input.success) throw new BadRequestException('A valid requestId is required.');
    if (!request.user.email || !z.email().safeParse(request.user.email).success) throw new BadRequestException('A verified email address is required.');
    const owner = createHash('sha256').update(request.user.id).digest('hex').slice(0,32);
    const jobId = await this.queue.enqueue({ userId: request.user.id, email: request.user.email }, `${owner}-${input.data.requestId}`);
    return { jobId };
  }
  @Get(':id')
  async status(@Req() request: AuthenticatedRequest, @Param('id') id: string) {
    if (!/^[a-f0-9]{32}-[a-f0-9-]{36}$/.test(id)) throw new NotFoundException();
    const result = await this.queue.status(id, request.user.id);
    if (!result) throw new NotFoundException();
    return result;
  }
}
