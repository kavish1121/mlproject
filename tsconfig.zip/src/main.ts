import 'reflect-metadata';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { config } from './config';
async function bootstrap() {
  const app = await NestFactory.create(AppModule, { bodyParser: true });
  app.setGlobalPrefix('api');
  app.enableCors({ origin: config.FRONTEND_ORIGIN });
  app.enableShutdownHooks();
  await app.listen(config.PORT, config.HOST);
  console.log(`Chat backend: http://${config.HOST}:${config.PORT} (${config.AUTH_MODE} authentication, ${config.API_MODE} APIs)`);
}
bootstrap().catch(() => { console.error('Startup failed. Check configuration and service connectivity.'); process.exitCode = 1; });
