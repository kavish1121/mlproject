import { inject, Injectable } from '@angular/core';
import { io, Socket } from 'socket.io-client';
import { AuthService } from './auth.service';
export interface ChatMessage { id: string; request_id: string; role: 'user'|'assistant'; content: string; status: 'pending'|'complete'|'failed'; created_at: string }
@Injectable({ providedIn: 'root' })
export class ChatService {
  private readonly auth = inject(AuthService);
  private socket?: Socket;
  connect() {
    this.socket = io({ autoConnect: false, auth: callback => {
      this.auth.token().then(token => callback({ token })).catch(() => callback({ token: '' }));
    } });
    this.socket.connect();
  }
  history() { return this.auth.request<ChatMessage[]>('/api/chat/history'); }
  async send(text: string, requestId: string): Promise<ChatMessage> {
    const token = await this.auth.token();
    if (!this.socket?.connected) throw new Error('Chat is reconnecting. Please try again in a moment.');
    return new Promise((resolve, reject) => {
      this.socket!.timeout(45000).emit('chat:send', { text, requestId, token }, (error: Error | null, response: { ok: boolean; message: ChatMessage; error: string }) => {
        if (error) reject(new Error('No reply received yet. Refresh history before sending again.'));
        else if (!response.ok) reject(new Error(response.error));
        else resolve(response.message);
      });
    });
  }
  disconnect() { this.socket?.disconnect(); }
}
