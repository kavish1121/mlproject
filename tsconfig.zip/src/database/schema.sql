CREATE TABLE IF NOT EXISTS chat_messages (
  id UUID PRIMARY KEY,
  sequence BIGSERIAL UNIQUE NOT NULL,
  user_id TEXT NOT NULL,
  request_id UUID NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('user', 'assistant')),
  content TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('pending', 'complete', 'failed')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (user_id, request_id, role)
);
CREATE INDEX IF NOT EXISTS chat_messages_user_time ON chat_messages(user_id, sequence);
