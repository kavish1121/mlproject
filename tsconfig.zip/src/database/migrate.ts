import { readFileSync } from 'node:fs';
import { Pool } from 'pg';
import { config } from '../config';
async function migrate() {
  const pool = new Pool({ connectionString: config.DATABASE_URL });
  try { await pool.query(readFileSync('src/database/schema.sql', 'utf8')); console.log('Database schema ready.'); }
  finally { await pool.end(); }
}
migrate().catch(() => { console.error('Migration failed. Check DATABASE_URL and PostgreSQL connectivity.'); process.exitCode = 1; });
