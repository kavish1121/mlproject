import { Injectable, OnModuleDestroy } from '@nestjs/common';
import { Pool } from 'pg';
import { config } from '../config';
@Injectable()
export class DatabaseService implements OnModuleDestroy {
  readonly pool = new Pool({ connectionString: config.DATABASE_URL, max: 10 });
  async onModuleDestroy() { await this.pool.end(); }
}
